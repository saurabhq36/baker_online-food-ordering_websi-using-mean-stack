// import { Injectable } from '@angular/core';
// import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
// import { Observable } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthenticationGuard implements  {
  
// }


import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree,CanActivate } from '@angular/router';
import { Observable } from 'rxjs';
import Swal from 'sweetalert2';
import {Router} from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationGuard implements CanActivate{

constructor(private router:Router){}

canActivate(email,password){
	if(email=="saurabh.kumar1_cs17@gla.ac.in"&&password=="123"){
		return true;
	}
	else{
		Swal.fire("oops","unauthorised acess","error");
		 this.router.navigate(['/']);
		return false;
	}

  
}




}  

