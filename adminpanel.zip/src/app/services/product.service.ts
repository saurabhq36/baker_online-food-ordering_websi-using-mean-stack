import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
url="http://localhost:7788/api/";
  constructor(private http:HttpClient) { }

  addpro(data)
  {
    return this.http.post(this.url+'addProduct',data);
  }

  getpro()
  {
    return this.http.get(this.url+"getproduct");
  }

  deleteproduct(id)
  {
    return this.http.get(this.url+"deleteproduct/"+id);
  }

  filterdata(d)
  {
    return this.http.get(this.url+"filterproduct/"+d);
  }

  fetchProById(id)
  {
    return this.http.get(this.url+"fetchprobyid/"+id);
  }

  changeproduct(data,cat_id){
    return this.http.post(this.url+"changeproduct/"+cat_id,data)
  }


}
