// // import { Component, OnInit } from '@angular/core';

// // @Component({
// //   selector: 'app-editcategory',
// //   templateUrl: './editcategory.component.html',
// //   styleUrls: ['./editcategory.component.css']
// // })
// // export class EditcategoryComponent implements OnInit {

// //   constructor() { }

// //   ngOnInit() {
// //   }

// // }





// import { Component, OnInit } from '@angular/core';
// import { FormGroup,FormBuilder,Validators } from '@angular/forms';
// import { ActivatedRoute} from '@angular/router';
// import { CategoryService } from 'src/app/services/category.service';
// @Component({
//   selector: 'app-editcategory',
//   templateUrl: './editcategory.component.html',
//   styleUrls: ['./editcategory.component.css']
// })
// export class EditcategoryComponent implements OnInit {
//   cat_id;
//   resData;
//   myForm:FormGroup;
//   constructor(private fb:FormBuilder,private ar:ActivatedRoute,private cser:CategoryService) { }

//   ngOnInit() {
//     this.validate();
//     this.ar.params.subscribe(par=>
//       {
//         this.cat_id=par.cid;
//         this.cser.fetchcatById(this.cat_id)
//         .subscribe(res=>
//           {
//          this.resData=res;
//          this.myForm.patchValue(this.resData.cdata[0])
//           })
//       })
//   }
//    validate()
//    {
//      this.myForm=this.fb.group({
//        'cname':['',Validators.required],
//        'description':['',Validators.required]
//      })
//    }
// }









import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators, FormsModule } from '@angular/forms';
import { ActivatedRoute,Router} from '@angular/router';
import { CategoryService } from 'src/app/services/category.service';
import { format } from 'util';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-editcategory',
  templateUrl: './editcategory.component.html',
  styleUrls: ['./editcategory.component.css']
})
export class EditcategoryComponent implements OnInit {
  cat_id;
  myImage;
  resData;
  myForm:FormGroup;
  constructor(private router:Router,private fb:FormBuilder,private ar:ActivatedRoute,private cser:CategoryService) { }

  ngOnInit() {
    this.validate();
    this.ar.params.subscribe(par=>
      {
        this.cat_id=par.cid;
        this.cser.fetchcatById(this.cat_id)
        .subscribe(res=>
          {
         this.resData=res;
         this.myForm.patchValue(this.resData.cdata[0])
          })
      })
  }



  editFormCategory(){
    let formData=new FormData();
    formData.append('id',this.cat_id);
    formData.append('cname',this.myForm.controls.cname.value);
    formData.append('description',this.myForm.controls.description.value)
    formData.append('Image',this.myImage);
    this.cser.changecategory(formData,this.cat_id).subscribe(res=>
      {
         this.router.navigate(['/dashboard/category'])
        Swal.fire({
          position: 'center',
          type: 'success',
          title: 'changes saved',
          showConfirmButton: false,
          timer: 1500
        })
        console.log(res);
      })
  }


  fileUpload(event){
    if(event.target.files.length>0){
      this.myImage=event.target.files[0];
    }
  }

   validate()
   {
     this.myForm=this.fb.group({
       'cname':['',Validators.required],
       'description':['',Validators.required]
     })
   }
}
