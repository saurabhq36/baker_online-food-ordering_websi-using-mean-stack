// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-category',
//   templateUrl: './category.component.html',
//   styleUrls: ['./category.component.css']
// })
// export class CategoryComponent implements OnInit {

//   resData;
//   catData;
//   msg;


//   constructor() { private catser:CategoryService}

//   ngOnInit() {

//     this.catser.getCat()
//     .subscribe(res=>
//       {
//          this.resData=res;
//          if(this.resData.err==0)
//          {
//            this.catData=this.resData.cdata;
//            console.log(this.catData);
//          }
//       })
//   }

// }






import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/services/category.service';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  resData;
  catData;
  msg;
  
  constructor(private catser:CategoryService) { }
  delcat(id)
  {
    if(confirm("do you want to delete this category")){
    this.catser.deletecategory(id)
    .subscribe(res=>
      {
        
        this.resData=res;
        if(this.resData.err==0)
        {
          this.msg=this.resData.msg;
          this.catser.getCat()
          .subscribe(res=>
            {
               this.resData=res;
               if(this.resData.err==0)
               {
                 this.catData=this.resData.cdata;
                 console.log(this.catData);
               }
            })
        }
      })
    }

              
// Swal.fire({
//   title: 'Are you sure?',
//   text: 'You will not be able to recover this  file!',
//   type: 'warning',
//   showCancelButton: true,
//   confirmButtonText: 'Yes, delete it!',
//   cancelButtonText: 'No, keep it'
// }).then((result) => {
//   if (result.value) {
//     this.catser.deletecategory(id)
//     .subscribe(res=>
//       {
        
//         this.resData=res;
//         if(this.resData.err==0)
//         {
//           this.msg=this.resData.msg;
//           this.catser.getCat()
//           .subscribe(res=>
//             {
//                this.resData=res;
//                if(this.resData.err==0)
//                {
//                  this.catData=this.resData.cdata;
//                  console.log(this.catData);
//               }
//             })
//         }
        
//       })
//     Swal.fire(
//       'Deleted!',
//       'Your file has been deleted.',
//       'success'
     
//     )


//   }
    
//     else if (result.dismiss === Swal.DismissReason.cancel) {
//     Swal.fire(
//       'Cancelled',
//       'Your  file is safe :)',
//       'error'
//     )
//   }
// })

  }


  ngOnInit() {
  //   this.catser.getCat()
  //   .subscribe(res=>
  //     {
  //        this.resData=res;
  //        if(this.resData.err==0)
  //        {
  //          this.catData=this.resData;
  //          console.log(this.catData);
  //        }
  //     })


  this.catser.getCat()
  .subscribe(res=>
    {
       this.resData=res;
       if(this.resData.err==0)
       {
         this.catData=this.resData.cdata;
         console.log(this.catData);
       }
    })
}

  }


