import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginService } from 'src/app/services/login.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';
import { ProductService } from 'src/app/services/product.service';
@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
myImage;
  myForm:FormGroup;

  constructor(private fb:FormBuilder,private lser:ProductService,private router:Router) { }



addproduct()
{
  let formData=new FormData();
  formData.append('productname',this.myForm.controls.productname.value);
  formData.append('brand',this.myForm.controls.brand.value);
  formData.append('description',this.myForm.controls.description.value);
  formData.append('cost',this.myForm.controls.cost.value);
  formData.append('Image',this.myImage);
  formData.append('category',this.myForm.controls.category.value);
  this.lser.addpro(formData)
  .subscribe(res=>
    {
      this.router.navigate(['/dashboard/product'])
      Swal.fire({
        position: 'center',
        type: 'success',
        title: 'Category saved',
        showConfirmButton: false,
        timer: 1500
      })
    })
}

fileUpload(event)
{
  if(event.target.files.length>0)
   {
     this.myImage=event.target.files[0];
    // console.log(this.myImage);
   }
}

  ngOnInit() {
    this.validate();
  }
  validate()
  {
    this.myForm=this.fb.group(
      {
        'productname':['',Validators.required],
        'brand':['',Validators.required],
        'description':['',Validators.required],
        'cost':['',Validators.required],
        'category':['',Validators.required]
      }
    )
  }

}
