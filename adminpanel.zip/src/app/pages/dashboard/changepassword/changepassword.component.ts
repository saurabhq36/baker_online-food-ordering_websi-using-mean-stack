import { Component, OnInit } from '@angular/core';
import{FormGroup,FormBuilder,Validators}  from '@angular/forms';
import { CategoryService } from 'src/app/services/category.service';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  myForm:FormGroup;

  constructor(private fb:FormBuilder,private cser:CategoryService) { }

  ngOnInit() {
    this.validate();
  }


getdata(){

let op=  this.myForm.controls.oldpassword.value;
let np=this.myForm.controls.newpassword.value;
  //formData.append('confirmpassword',this.myForm.controls.oldpassword.value);
  let uid=localStorage.getItem('userId');
  this.cser.changepassworddata({'oldpassword':op,'newpassword':np,'userId':uid}).subscribe(res=>
    {
      console.log(res);
    })
  }

validate()
   {
     this.myForm=this.fb.group({
       'oldpassword':['',Validators.required],
       'newpassword':['',Validators.required],
       'confirmpassword':['',Validators.required]
     })
   }

}
