import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/services/category.service';
@Component({
  selector: 'app-default',
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.css']
})
export class DefaultComponent implements OnInit {
resData;
catData;
  constructor(private catser:CategoryService) { }

  ngOnInit() {
    this.catser.getfeedback()
  .subscribe(res=>
    {
       this.resData=res;
       if(this.resData.err==0)
       {
         this.catData=this.resData.cdata;
         console.log(this.catData);
       }
    })
  }

}
