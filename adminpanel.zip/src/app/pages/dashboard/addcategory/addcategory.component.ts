// // import { Component, OnInit } from '@angular/core';

// // @Component({
// //   selector: 'app-addcategory',
// //   templateUrl: './addcategory.component.html',
// //   styleUrls: ['./addcategory.component.css']
// // })
// // export class AddcategoryComponent implements OnInit {

// //   constructor() { }

// //   ngOnInit() {
// //   }

// // }



// import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// import { CategoryService } from 'src/app/services/category.service';
// @Component({
//   selector: 'app-addcategory',
//   templateUrl: './addcategory.component.html',
//   styleUrls: ['./addcategory.component.css']
// })
// export class AddcategoryComponent implements OnInit {
//   myForm:FormGroup;
//   myImage;



//   public imagePath;
//   imgURL: any;
//   public message: string;


//   constructor(private fb:FormBuilder,private catser:CategoryService) { }

//   ngOnInit() {
//     this.validate();
//   }



 
//   preview(files) {
//     if (files.length === 0)
//       return;
 
//     var mimeType = files[0].type;
//     if (mimeType.match(/image\/*/) == null) {
//       this.message = "Only images are supported.";
//       return;
//     }
 
//     var reader = new FileReader();
//     this.imagePath = files;
//     reader.readAsDataURL(files[0]); 
//     reader.onload = (_event) => { 
//       this.imgURL = reader.result; 
//     }
//   }


// //////////////////////////////////





//   fileUpload(event)
//   {
//     if(event.target.files.length>0)
//      {
//        this.myImage=event.target.files[0];
//        console.log(this.myImage);
//      }
//   }

//   // view(){
//   //   if(this.flag==1)
//   //   return true;
//   // }
  
//   addFormCategory()
//   {
//     let formData=new FormData();
//     formData.append('cname',this.myForm.controls.cname.value);
//     formData.append('description',this.myForm.controls.description.value);
//     formData.append('Image',this.myImage);
//     this.catser.addCat(formData)
//     .subscribe(res=>
//       {
//         console.log(res);
//       })
//   }
//   validate()
//   {
//     this.myForm=this.fb.group(
//       {
//         'cname':['',Validators.required],
//         'description':['',Validators.required]
//       }
//     )
//   }
// }


import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CategoryService } from 'src/app/services/category.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-addcategory',
  templateUrl: './addcategory.component.html',
  styleUrls: ['./addcategory.component.css']
})
export class AddcategoryComponent implements OnInit {
  myForm:FormGroup;
  myImage;
  constructor(private fb:FormBuilder,private catser:CategoryService,private router:Router) { }

  ngOnInit() {
    this.validate();
  }

  
  fileUpload(event)
  {
    if(event.target.files.length>0)
     {
       this.myImage=event.target.files[0];
       console.log(this.myImage);
     }
  }
  addFormCategory()
  {
    let formData=new FormData();
    formData.append('cname',this.myForm.controls.cname.value);
    formData.append('description',this.myForm.controls.description.value);
    formData.append('Image',this.myImage);
    this.catser.addCat(formData)
    .subscribe(res=>
      {
        this.router.navigate(['/dashboard/category'])
        Swal.fire({
          position: 'center',
          type: 'success',
          title: 'Category saved',
          showConfirmButton: false,
          timer: 1500
        })
      })
  }
  validate()
  {
    this.myForm=this.fb.group(
      {
        'cname':['',Validators.required],
        'description':['',Validators.required]
      }
    )
  }
}







