import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ProductService } from 'src/app/services/product.service';
import {Router} from '@angular/router';
import { ActivatedRoute} from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-editproduct',
  templateUrl: './editproduct.component.html',
  styleUrls: ['./editproduct.component.css']
})
export class EditproductComponent implements OnInit {
  cat_id;
  myImage;
  resData;
  myForm:FormGroup;
  constructor(private fb:FormBuilder,private ar:ActivatedRoute,private lser:ProductService,private router:Router) { }

  ngOnInit() {
    this.validate();
    this.ar.params.subscribe(par=>
      {
        this.cat_id=par.cid;
        this.lser.fetchProById(this.cat_id)
        .subscribe(res=>
          {
         this.resData=res;
         this.myForm.patchValue(this.resData.cdata[0])
          })
      })
    }

      editFormProduct(){
        let formData=new FormData();
        formData.append('id',this.cat_id);
        formData.append('productname',this.myForm.controls.productname.value);
        formData.append('brand',this.myForm.controls.brand.value)
        formData.append('description',this.myForm.controls.description.value)
        formData.append('Image',this.myImage);
        formData.append('cost',this.myForm.controls.cost.value)
        formData.append('category',this.myForm.controls.category.value)
        this.lser.changeproduct(formData,this.cat_id).subscribe(res=>
          {
            this.router.navigate(['/dashboard/product'])
      Swal.fire({
        position: 'center',
        type: 'success',
        title: 'Category edited',
        showConfirmButton: false,
        timer: 1500
      })
          })
      }
    
    
      fileUpload(event){
        if(event.target.files.length>0){
          this.myImage=event.target.files[0];
        }
      }
    

  

  validate(){
    this.myForm=this.fb.group(
      {
        'productname':['',Validators.required],
        'brand':['',Validators.required],
        'description':['',Validators.required],
        'cost':['',Validators.required],
        'category':['',Validators.required]
      }
    )
  }

}
