import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product.service';
import { FormGroup, FormBuilder, Validators,FormControl } from '@angular/forms';
import Swal from 'sweetalert2'
import { CategoryService } from 'src/app/services/category.service';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
resData;
catData;
catData1;
msg;


  constructor(private proser:ProductService,private catser:CategoryService) { }
//myForm:FormGroup;
myForm = new FormGroup({
 all: new FormControl()
});

  delpro(id)
  {              
Swal.fire({
  title: 'Are you sure?',
  text: 'You will not be able to recover this  file!',
  type: 'warning',
  showCancelButton: true,
  confirmButtonText: 'Yes, delete it!',
  cancelButtonText: 'No, keep it'
}).then((result) => {
  if (result.value) {
    this.proser.deleteproduct(id)
    .subscribe(res=>
      {
        
        this.resData=res;
        if(this.resData.err==0)
        {
          this.msg=this.resData.msg;
          this.proser.getpro()
          .subscribe(res=>
            {
               this.resData=res;
               if(this.resData.err==0)
               {
                 this.catData=this.resData.cdata;
                 console.log(this.catData);
               }
            })
        }
      })
    Swal.fire(
      'Deleted!',
      'Your file has been deleted.',
      'success'
     
    )}
    
    else if (result.dismiss === Swal.DismissReason.cancel) {
    Swal.fire(
      'Cancelled',
      'Your  file is safe :)',
      'error'
    )
  }
})

  }


filter()
{
  let d=this.myForm.controls.all.value;
  if(d=="allpro")
  {
    this.proser.getpro()
    .subscribe(res=>
      {
         this.resData=res;
         if(this.resData.err==0)
         {
           this.catData=this.resData.cdata;
          // console.log(this.catData);
         }
      })
  }


  else{
  this.proser.filterdata(d).subscribe(res=>
    {
      this.resData=res;
      if(this.resData.err==0)
      this.catData=this.resData.cdata;
      //console.log(res);
    })
  }

}
  ngOnInit() {
    this.proser.getpro()
    .subscribe(res=>
      {
         this.resData=res;
         if(this.resData.err==0)
         {
           this.catData=this.resData.cdata;
          // console.log(this.catData);
         }
      })


      this.catser.getCat()
    .subscribe(res=>
      {
         this.resData=res;
         if(this.resData.err==0)
         {
           this.catData1=this.resData.cdata;
           console.log(this.catData1);
         }
      })
      
  }
  
  

}
