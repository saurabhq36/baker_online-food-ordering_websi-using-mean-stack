import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { DefaultComponent } from './pages/dashboard/default/default.component';
//import { NewcomponentComponent } from './pages/dashboard/newcomponent/newcomponent.component';
import { CategoryComponent } from './pages/dashboard/category/category.component';
import { AddcategoryComponent } from './pages/dashboard/addcategory/addcategory.component';
import { EditcategoryComponent } from './pages/dashboard/category/editcategory/editcategory.component';
import { ProductComponent } from './pages/dashboard/product/product.component';
//import { AuthenticationGuard } from './gaurds/authentication.guard';
import { ChangepasswordComponent } from './pages/dashboard/changepassword/changepassword.component';
import { AddproductComponent } from './pages/dashboard/addproduct/addproduct.component';
import { EditproductComponent } from './pages/dashboard/product/editproduct/editproduct.component';
//const routes: Routes = [];


const routes: Routes = [
  {path:"",component:LoginComponent},
  {path:'dashboard',component:DashboardComponent,children:[
    {path:'',component:CategoryComponent},
    {path:'default',component:DefaultComponent},
    {path:'changepassword',component:ChangepasswordComponent},
    {path:'category',component:CategoryComponent},
    {path:'addcategory',component:AddcategoryComponent},
    {path:'editcategory/:cid',component:EditcategoryComponent},
    {path:'product',component:ProductComponent},
    {path:'addproduct',component:AddproductComponent},
    {path:'editproduct/:cid',component:EditproductComponent}
  ]}
  ];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
