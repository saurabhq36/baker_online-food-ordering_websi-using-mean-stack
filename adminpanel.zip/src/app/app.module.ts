import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './pages/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { DefaultComponent } from './pages/dashboard/default/default.component';
import { NewcomponentComponent } from './pages/dashboard/newcomponent/newcomponent.component';
import { CategoryComponent } from './pages/dashboard/category/category.component';
import { AddcategoryComponent } from './pages/dashboard/addcategory/addcategory.component';
import { EditcategoryComponent } from './pages/dashboard/category/editcategory/editcategory.component';
import { ProductComponent } from './pages/dashboard/product/product.component';
import { ChangepasswordComponent } from './pages/dashboard/changepassword/changepassword.component';
import { AddproductComponent } from './pages/dashboard/addproduct/addproduct.component';
import { EditproductComponent } from './pages/dashboard/product/editproduct/editproduct.component';
//import { AddproductComponent } from './dashboard/addproduct/addproduct.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    DefaultComponent,
    NewcomponentComponent,
    CategoryComponent,
    AddcategoryComponent,
    EditcategoryComponent,
    ProductComponent,
    ChangepasswordComponent,
    AddproductComponent,
    EditproductComponent,
  //  AddproductComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, 
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
