const express=require('express');
const cors=require('cors');
const bodyParser=require('body-parser');
const sha1=require('sha1');

//node mailer for sending mails
const nodemailer = require("nodemailer");
const transporter = nodemailer.createTransport({
    service: 'gmail',
    port: 465,
    secure: true,
    auth: {
      user: 'saurabhq36@gmail.com',
      pass: 'vedprakash'
    }
  });
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";







//for uploading
const multer=require('multer');
const path="./attach";
let storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null,path)
    },
    filename: function (req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now()+ '.' + file.originalname.split('.')[file.originalname.split('.').length -1])
    }
  })
  
  let upload = multer({ storage: storage }).single('Image');


const mongoose=require('mongoose');
//connect mongoose to mongodb 
mongoose.connect("mongodb://localhost/myproo", {
    useCreateIndex: true,
    useNewUrlParser: true
  });
let adminLogin=require('./database/adminlogin');
let catModel=require('./database/category');
let product=require('./database/product');
let feedModel=require('./database/feedback');
let cartModel=require('./database/cart');
let userlogin=require('./database/userlogin');
let orderModel=require('./database/order')

let app=express();
app.use(cors());
app.use(bodyParser.json());








let myemail;

//login
app.post('/api/adminlogin',function(req,res)
{
    let email=req.body.email;
    let password=sha1(req.body.password);

//    /// for insert data 
//     // let ins=new adminLogin({'email':email,'password':password});
//     // ins.save(function(err)
//     // {
//     //     if(err){}
//     //     else
//     //     {
//     //         res.json({'msg':'Data Save'})
//     //     }
//     // })
   
   
   
adminLogin.find({'email':email,'password':password},function(err,data)
    {
       if(err){}
       else if(data.length==0)
       {
           res.json({'err':1,'msg':'Email or password is not correct'})
       }
       else
       {
           res.json({'err':0,'msg':'login succes','user':email});
           
       }
    })

})




//addcategory 
app.post('/api/addCategory',function(req,res)
{
   upload(req,res,function(err)
   {
       if(err){}
       else
       {
           let cname=req.body.cname;
           let description=req.body.description;
           let imgname=req.file.filename;
           let ins=new catModel({'cname':cname,'description':description,'image':imgname});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                   res.json({'err':0,'msg':'category Saved'})
               }
           })
       }
   })
})



//fetch cat by id 
app.get('/api/fetchcatbyid/:id',function(req,res)
{
    let cid=req.params.id;
    catModel.find({'_id':cid},function(err,data)
    {
        if(err){}
        else{
            res.json({'err':0,'cdata':data});
        }
    })
})


//change password
app.post('/api/changepass',function(req,res){

   let op=sha1(req.body.oldpassword);
    let np=sha1(req.body.newpassword);
    let cid=req.body.userId;

    adminLogin.find({'email':cid},function(err,data){
    if(err){}
    
    else{
        let dbpass=data[0].password;
        if(op==dbpass){
            console.log(op+" "+dbpass);
        adminLogin.update({'email':cid},{$set:{'password':np}},function(err)
        {
         if(err)
         {}
         else
         {
             res.json({'err':0,'msg':'password changed'})
         }
        })
    }
    else{
        res.json({'err':1,'msg':'old password is incorrect'});
    }

    }
    })
})



app.use('/images',express.static('attach'))

//get all data
app.get('/api/getcategory',function(req,res){
    catModel.find({},function(err,data){
        if(err){
            res.json({'err':1,'msg':'some error'})
        }
        else
        {
            res.json({'err':0,'cdata':data})
        }
    })
})



// cid;
// app.get('/api/deletecategory',function(req,res){
//     this.cid=
//     catModel.remove({'_id':cid},function(err,data){
//         if(err){
//             res.json({'err':1,'msg':'some error'})
//         }
//         else
//         {
//             res.json({'err':0,'cdata':data})
//         }
//     })
// })








//delete category
// app.get('/api/delcat/:id',function(req,res)
// {
//     let catid=req.params.id;
//     console.log(catid);
//     catModel.remove({'_id':catid},function(err)
//     {
//         if(err){}
//         else
//         {
//             res.json({'err':0,'msg':'category deleted'});
//         }
//     })
// })







//trial delele product by delete category
app.get('/api/delcat/:id',function(req,res)
{
    let catid=req.params.id;
    catModel.find({'_id':catid},function(err,data){
        if(err){
            res.json({'err':1,'msg':'some error'})
        }
        else
        {
            //res.json({'err':0,'cdata':data})

            let catname=data[0].cname
            
console.log(catname);
        product.remove({'category':catname},function(err)
            {
                if(err){}
                else
                {
                 //   res.json({'err':0,'msg':'category deleted'});
                }
            })
        }
    })

            catModel.remove({'_id':catid},function(err)
            {
            if(err){}
                else
                {
                   // res.json({'err':0,'msg':'category deleted'});
               }
            })
        
    res.json({'err':0,'msg':'both edited'})
})






//editcategory
 //app.post('/api/changecategory/:id',function(req,res){
//     //console.log("hello");
// upload(req,res,function(err){
// if(err)
// {}
// else{
//     let id=req.body.id;
//     let cname=req.body.cname;
//     let description=req.body.description;
//     let imgname=req.file.filename;
//     // console.log(imgname);
//     catModel.update({'_id':id},{$set:{'cname':cname,'description':description,'image':imgname,'created_at':Date.now()}},function(err){
//         if(err){}
//         else{
//             res.json({'err':0,'msg':'category updated'});
//         }
//     })
// }
// })
 //})


//edit category trial
app.post('/api/changecategory/:id',function(req,res){
    upload(req,res,function(err){
    if(err)
    {}
    else{
        let id=req.body.id;
        let cname=req.body.cname;
        let description=req.body.description;
        let imgname=req.file.filename;
        
        
        
        catModel.find({'_id':id},function(err,data){
            if(err){
                res.json({'err':1,'msg':'some error'})
            }
            else
            {
                //res.json({'err':0,'cdata':data})
    
                let catname=data[0].cname
                
            product.update({'category':catname},{$set:{'category':cname}},function(err)
                {
                    if(err){}
                    else
                    {
                     //   res.json({'err':0,'msg':'category deleted'});
                    }
                })
            }
        })
    
        
        
        
        catModel.update({'_id':id},{$set:{'cname':cname,'description':description,'image':imgname,'created_at':Date.now()}},function(err){
            if(err){}
            else{
                res.json({'err':0,'msg':'category updated'});
            }
        })
    }
    })
    })







//addproduct by admin panel
app.post('/api/addproduct',function(req,res)
{
   upload(req,res,function(err)
   {
       if(err){}
       else
       {
           let productname=req.body.productname;
           let brand=req.body.brand;
           let description=req.body.description;
           let imgname=req.file.filename;
           let cost=req.body.cost;
           let category=req.body.category;

           let ins=new product({'productname':productname,'brand':brand,'description':description,'image':imgname,'cost':cost,'category':category});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                   res.json({'err':0,'msg':'product Saved'})
               }
           })
       }
   })
})


//get all product data
app.get('/api/getproduct',function(req,res){
    product.find({},function(err,data){
        if(err){
            res.json({'err':1,'msg':'some error'})
        }
        else
        {
            res.json({'err':0,'cdata':data})
        }
    })
})



//delete product item

app.get('/api/deleteproduct/:id',function(req,res)
{
    let catid=req.params.id;
    product.remove({'_id':catid},function(err)
    {
        if(err){}
        else
        {
            res.json({'err':0,'msg':'category deleted'});
        }
    })
})



//filter product by category
app.get('/api/filterproduct/:id',function(req,res){

    let catid=req.params.id;
    console.log(catid);
    product.find({'category':catid},function(err,data){
        if(err){}
        else
        {
            res.json({'err':0,'cdata':data})
        }
    })
 })



//fetch pro by id
app.get('/api/fetchprobyid/:id',function(req,res)
{
    let cid=req.params.id;
    product.find({'_id':cid},function(err,data)
    {
        if(err){}
        else{
            res.json({'err':0,'cdata':data});
        }
    })
})



//edit product
app.post('/api/changeproduct/:id',function(req,res){
    //console.log("hello");
upload(req,res,function(err){
if(err)
{}
else{
    let id=req.body.id;
    let productname=req.body.productname;
    let brand=req.body.brand;
    let description=req.body.description;
    let imgname=req.file.filename;
    let cost=req.body.cost;
    let category=req.body.category;
    // console.log(imgname);
    product.update({'_id':id},{$set:{'productname':productname,'brand':brand,'description':description,'image':imgname,'cost':cost,'category':category}},function(err){
        if(err){}
        else{
            res.json({'err':0,'msg':'product updated'});
        }
    })
}
})
})

//feedback in DB and send mail
app.post('/api/feedback',function(req,res){
    console.log("hello")
    let name=req.body.name;
    let mobile=req.body.mobile;
    let feedback=req.body.feedback;
    let ins=new feedModel({'name':name,'mobile':mobile,'feedback':feedback});
     ins.save(function(err)
 {
     if(err){}
     else
    {

        let mailOptions = {
            from: 'saurabh36@gmail.com',
            to: 'saurabhq36@gmail.com',
            subject: 'Feedback From Website',
            //text:'hello'
            html: 'Name :'+name
          };
          transporter.sendMail(mailOptions, function(error, info){
            if (error) {
              console.log(error);
              res.json({'err':1,'msg':'Not send'})
            } else {
              console.log('Email sent: ' + info.response);
              res.json({'err':0,'msg':'Feedback Sent'});
            }
          });
    }
 })
})




app.get('/api/getfeedback',function(res,res){
    feedModel.find({},function(err,data){
        if(err){
            res.json({'err':1,'msg':'some error'})
        }
        else
        {
            res.json({'err':0,'cdata':data})
        }
    })
})



//fetch particular product details
app.get('/api/productdetail/:productname',function(req,res)
{
    let productname=req.params.productname;
    product.find({'productname':productname},function(err,data)
    {
        if(err){}
        else{
            res.json({'err':0,'cdata':data});
        }
    })
})


//add product in cart
app.get('/api/addtocart/:productname',function(req,res)
{
    let pname=req.params.productname;
    let cost;
    let image
   product.find({'productname':pname},function(err,data){
       if(err){

       }
       else{
          res.json({'err':0,'cdata':data})
           pname=data[0].productname;
           cost=data[0].cost;
           image=data[0].image
           quantity=1;
          console.log(pname+" "+cost+" "+image);

       }

           let ins=new cartModel({'username':myemail,'productname':pname,'image':image,'cost':cost,'quantity':quantity});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                  // res.json({'err':0,'msg':'added to cart'})
               }
           })
          
   })
   //res.json({'err':0,'msg':'product added to cart'})
})


//get product from cart
app.get('/api/getproductfromcart',function(req,res){
    sum=0;
    console.log(myemail)
    cartModel.find({'username':myemail},function(err,data){
        if(err){
            res.json({'err':1,'msg':'some error'})
        }
        else
        {
            
            for(i=0;i<data.length;i++)
            {
                sum=sum+(parseInt(data[i].cost)*(data[i].quantity))
            }
            console.log(sum);
            res.json({'err':0,'cdata':data,'sum':sum})
        }
    })
})



//delete product from cart
app.get('/api/deletecartproduct/:id',function(req,res)
{
    let catid=req.params.id;
    cartModel.remove({'_id':catid},function(err)
    {
        if(err){}
        else
        {
            res.json({'err':0,'msg':'category deleted'});
        }
    })
})










//add quantity in product
app.get('/api/addquantity/:id',function(req,res){
        let id=req.params.id;
        let catname;
        console.log(id)
        cartModel.find({'_id':id},function(err,data){
            if(err){
            }
            else
            {
                
                 catname=data[0].quantity;
                catname=catname+1;
           //   res.json({'err':0,'cdata':data})
            
            cartModel.updateOne({'_id':id},{$set:{'quantity':catname}},function(err)
                {
                    if(err){}
                    else
                    {
      //                 res.json({'err':0,'msg':'quantity added'});
      res.json({'err':0,'cdata':data})
                    }
                })
            }
            })
    })
    







//minus quantity in product
app.get('/api/minusquantity/:id',function(req,res){
    let id=req.params.id;
    let catname;
    console.log(id)
    cartModel.find({'_id':id},function(err,data){
        if(err){
        }
        else
        {
            
             catname=data[0].quantity;
            catname=catname-1;
       //   res.json({'err':0,'cdata':data})
        if(catname>=1){
        cartModel.updateOne({'_id':id},{$set:{'quantity':catname}},function(err)
            {
                if(err){}
                else
                {
  //                 res.json({'err':0,'msg':'quantity added'});
  res.json({'err':0,'cdata':data})
                }
            })
        }
        else{
            res.json({'err':0,'cdata':data})
        }
        }
        })
})



 


//insert data into userlogin
app.post('/api/userlogin',function(req,res)
{
    
    let email=req.body.email;
    let password=req.body.password;
    let ins=new userlogin({'email':email,'password':password});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                  res.json({'err':0,'msg':'data saved'})
               }
           })

})





//find userid and password in user database
app.post('/api/userlogindata',function(req,res)
{
    let email=req.body.email;
    let password=req.body.password;


   
userlogin.find({'email':email,'password':password},function(err,data)
    {
       if(err){}
       else if(data.length==0)
       {
           res.json({'err':1,'msg':'Email or password is not correct'})
       }
       else
       {
           myemail=data[0].email;
           res.json({'err':0,'msg':'login succes','user':email});
           
       }
    })

})










app.get('/api/orderproduct/:addr',function(req,res){
    let productdetails="";
    let username;
    let sum=0
    let address=req.params.addr;
    console.log(address)
    console.log(myemail)
    cartModel.find({'username':myemail},function(err,data){
        if(err){
            res.json({'err':1,'msg':'some error'})
        }
        else
        {
            
             
            for(i=0;i<data.length;i++)
            {
                sum=sum+(parseInt(data[i].cost)*(data[i].quantity))
            }


            for(i=0;i<data.length-1;i++)
            {
                 username=data[i].username
                let productname=data[i].productname
                let quantity=data[i].quantity
                

//new          
                productdetails=productdetails+""+productname+" x "+quantity+"," 

            }
            productdetails=productdetails+""+data[data.length-1].productname+" x "+data[data.length-1].quantity
                let ins=new orderModel({'username':username,'productname':productdetails,'quantity':sum,'address':address});
                ins.save(function(err)
                {
                    if(err){}
                    else
                    {
                       
                    }
                })
           //earlier for end }
             
            cartModel.remove({'username':myemail},function(err)
            {
                if(err){}
                else
                {
                   // res.json({'err':0,'msg':'category deleted'});
                }
            })

            //console.log(sum);
            res.json({'err':0,'cdata':data})
        }
    })
})







app.get('/api/getorder',function(req,res){
    
    console.log("hi its get order")
    orderModel.find({'username':myemail},function(err,data){
        if(err){
            res.json({'err':1,'msg':'some error'})
        }
        else
        {
            res.json({'err':0,'cdata':data})
        }
    })
})










app.listen(7788,function()
{
    console.log("Work on 7788");
})