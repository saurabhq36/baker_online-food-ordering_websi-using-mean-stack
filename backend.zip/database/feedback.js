/* category schema */
const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const feed = new Schema({
    name:String,
    mobile:String,
    feedback:String
});
module.exports = mongoose.model('feedback',feed);