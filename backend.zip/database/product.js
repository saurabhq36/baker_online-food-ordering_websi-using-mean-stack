/* category schema */
const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const pro = new Schema({
    productname:{type:String,unique:true},
    brand:String,
    description:String,
    image:String,
    cost:String,
    category:String
});
module.exports = mongoose.model('product',pro);