/* category schema */
const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const userlogin = new Schema({
    email:{type:String,unique:true},
    password:String,
});
module.exports = mongoose.model('userlogin',userlogin);