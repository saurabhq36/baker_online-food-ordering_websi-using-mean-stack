const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const order = new Schema({
    username:String,
    productname:String,
    quantity:Number,
    address:String,
    created_at:{ type: Date, default: Date.now }
});
module.exports = mongoose.model('order',order);