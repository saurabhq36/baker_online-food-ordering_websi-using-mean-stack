import { Component, OnInit } from '@angular/core';
import {FormGroup , FormBuilder , Validators} from '@angular/forms';
import {AbstractControl} from '@angular/forms';
import { ProductService } from '../services/product.service';

// function ageRangeValidator(control: AbstractControl): 
// { [key: string]: boolean } | null 
// {
//       if (control.value !== undefined && (isNaN(control.value) || control.value < 18 || 
//       control.value > 45))
//       {
//       return { 'ageRange': true };
//       }
//         return null;
// }



@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
	myForm:FormGroup
  constructor(private fb:FormBuilder,private pser:ProductService) { }
msg;
contact(){
	// let name = this.myForm.controls.name.value;  to get value of one field
  let formData = this.myForm.getRawValue(); //all values in an object
 // console.log(formData)
  this.pser.sendfeedback(formData).subscribe(res=>
    {
      console.log(res);
    this.msg=res;
    this.msg=this.msg.msg
    }
  )
}
  ngOnInit() {
  	this.validate();
  }

  validate()
  {
    this.myForm=this.fb.group
    (
	    {
	    		'name'   : ['',Validators.required],
	    		'mobile' : ['',[Validators.required,Validators.pattern("^[6789][0-9]{9}$")]],
          'feedback'    : ['',Validators.required]
	    	//	'pass'   : ['',[Validators.required,Validators.pattern("^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,30}$")]]
	    }		
    ) 	
  }


}
