import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from '../services/product.service';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-productdetail',
  templateUrl: './productdetail.component.html',
  styleUrls: ['./productdetail.component.css']
})
export class ProductdetailComponent implements OnInit {
productname;
resdata;
catData;
  constructor(private ar:ActivatedRoute,private catser:ProductService) { }


  addtocart(pname){
    let a=localStorage.getItem('userId')
    if(a!=undefined){
    this.catser.addprotocart(pname).subscribe(res=>
      {
        Swal.fire({
          position: 'center',
          type: 'success',
          title: 'added to cart',
          showConfirmButton: false,
          timer: 3000
        })
      console.log(res);
  })
}
else
{
  Swal.fire({
    position: 'center',
    type: 'error',
    title: 'please login',
    showConfirmButton: false,
    timer: 3000
  })
}
  }





  ngOnInit() {
    this.ar.params.subscribe(par=>
      {
        this.productname=par.productname;
        console.log(this.productname)
        this.catser.fetchProductName(this.productname).subscribe(res=>
          {
            this.resdata=res;
            this.catData=this.resdata.cdata
          }
          )
      })
    
  }

}
