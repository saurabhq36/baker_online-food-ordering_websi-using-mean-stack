import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.css']
})
export class PortfolioComponent implements OnInit {
msg;
  constructor(private router:Router) { }

  ngOnInit() {
    let search=localStorage.getItem('search')
    if(search!=undefined&&search!="")
    {
      this.router.navigate(['/search']);
    }
    else{
     this.msg="write something" 
    }
  }

}
