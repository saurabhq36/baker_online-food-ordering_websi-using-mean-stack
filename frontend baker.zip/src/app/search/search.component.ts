import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
resdata;
catData;

  constructor(private proser:ProductService) { }

  ngOnInit() {
    let search=localStorage.getItem('search')
    //console.log(search)
    this.proser.fetchProductName(search).subscribe(res=>
      {
        this.resdata=res;
      if(this.resdata.err==0){
        this.catData=this.resdata.cdata
      }
      
      })
  }

}
