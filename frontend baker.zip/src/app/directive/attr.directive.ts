import { Directive ,ElementRef,HostListener,HostBinding} from '@angular/core';

@Directive({
  selector: '[appAttr]'
})
export class AttrDirective {

  constructor(private er:ElementRef) { 
  	//er.nativeElement.style.color="#28a745"
  }

  @HostListener('mouseover') onMouseOver(){
  	this.er.nativeElement.style.color="#28a745";
  }
  @HostBinding('style.color') color :String; //errwith host binding 

  @HostListener('mouseleave') onMouseLeave(){
  	this.er.nativeElement.style.color="white";
  }

  }

