import { Directive , TemplateRef , ViewContainerRef ,Input} from '@angular/core';

@Directive({
  selector: '[appStr]'
})
export class StrDirective {

 // constructor(private vr :ViewContainerRef , private tr : TemplateRef<any>) { }
//   @Input() set appStr(condition :boolean)
//   {
//   	if(condition)
//   		{
//   			this.vr.createEmbeddedView(this.Str)
//   		}
//   		else
//   		{
//   			this.vr.clear();
//   		}
//   }

 }
