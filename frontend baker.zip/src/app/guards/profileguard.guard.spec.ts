import { TestBed, async, inject } from '@angular/core/testing';

import { ProfileguardGuard } from './profileguard.guard';

describe('ProfileguardGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProfileguardGuard]
    });
  });

  it('should ...', inject([ProfileguardGuard], (guard: ProfileguardGuard) => {
    expect(guard).toBeTruthy();
  }));
});
