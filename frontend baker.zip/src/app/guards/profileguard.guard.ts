import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree,CanActivate } from '@angular/router';
import { Observable } from 'rxjs';
import { Router} from '@angular/router';
import Swal from 'sweetalert2';
@Injectable({
  providedIn: 'root'
})
export class ProfileguardGuard implements CanActivate  {
constructor(private router:Router){}

	canActivate()
	{
		let 	uname="ab";
		let 	pass ="123";

		if(uname=="abc" && pass =="123")
		{
			Swal.fire({
			  position: 'center',
			  type: 'success',
			  title: 'Your are successfully logged in',
			  showConfirmButton: false,
			  timer: 1500
			});
			return true;
		}
		else
		{
			Swal.fire("Oops","You are not authorized to access this page",'error');
			this.router.navigate(['/']);
			//return false;


			// Swal.fire({
			//   title: 'Are you sure?',
			//   text: 'You will not be able to recover this imaginary file!',
			//   type: 'warning',
			//   showCancelButton: true,
			//   confirmButtonText: 'Yes, delete it!',
			//   cancelButtonText: 'No, keep it'
			// }).then((result) => {
			//   if (result.value) {
			//     Swal.fire(
			//       'Deleted!',
			//       'Your imaginary file has been deleted.',
			//       'success'
			//     )
			//   // For more information about handling dismissals please visit
			//   // https://sweetalert2.github.io/#handling-dismissals
			//   } else if (result.dismiss === Swal.DismissReason.cancel) {
			//     Swal.fire(
			//       'Cancelled',
			//       'Your imaginary file is safe :)',
			//       'error'
			//     )
			//   }
			// })



		}
	}

  
}
