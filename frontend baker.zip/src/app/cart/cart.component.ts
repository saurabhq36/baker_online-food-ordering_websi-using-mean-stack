import { Component, OnInit } from '@angular/core';
import {FormGroup , FormBuilder , Validators} from '@angular/forms';
import { ProductService } from '../services/product.service';
import Swal from 'sweetalert2'
import { Router} from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
resData;
catData;
sum;
msg;

myForm:FormGroup
  constructor(private proser:ProductService,private fb:FormBuilder,private router:Router) { }
  
  order(){
    let addr=this.myForm.controls.address.value;
    this.proser.orderproduct(addr).subscribe(res=>
      {
        

        this.resData=res;

         if(this.resData.err==0)
         {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'ordered sucessfully',
            showConfirmButton: false,
            timer: 3000
          })
          this.router.navigate(['/order'])

          }


      })
  }


  deletecartproduct(pid){
    //console.log(pid);
    let a=localStorage.getItem('userId')
    if(a!=undefined){
    this.proser.deleteproductfromcart(pid).subscribe(res=>
      {
        

        this.resData=res;
        if(this.resData.err==0)
        {
          this.msg=this.resData.msg;
          this.proser.getprofromcart()
          .subscribe(res=>
            {
               this.resData=res;
               if(this.resData.err==0)
               {
                 this.catData=this.resData.cdata;
                 this.sum=this.resData.sum;
               }
            })
        }



      })
    }
    else
    {
      Swal.fire({
        position: 'center',
        type: 'error',
        title: 'please login',
        showConfirmButton: false,
        timer: 3000
      })
    }
  }




    
     addquantity(pid){
  //     console.log(pid)
  let a=localStorage.getItem('userId')
    if(a!=undefined){
       this.proser.addquantity(pid).subscribe(res=>
        {
          this.resData=res;
            //this.msg=this.resData.msg;
            this.proser.getprofromcart()
            .subscribe(res=>
              {
                 this.resData=res;
                 if(this.resData.err==0)
                 {
                   this.catData=this.resData.cdata;
                   this.sum=this.resData.sum;
                 }
              })
  
        })
     
      }
      else{
        Swal.fire({
          position: 'center',
          type: 'error',
          title: 'please login',
          showConfirmButton: false,
          timer: 3000
        })
      }
    }







     minusquantity(pid){
//      console.log(pid)
let a=localStorage.getItem('userId')
if(a!=undefined){
      this.proser.minusquantity(pid).subscribe(res=>
       {
         this.resData=res;
           //this.msg=this.resData.msg;
           this.proser.getprofromcart()
           .subscribe(res=>
             {
                this.resData=res;
                if(this.resData.err==0)
                {
                  this.catData=this.resData.cdata;
                  this.sum=this.resData.sum;
                }
             })
 
       })
    }
    else{
      Swal.fire({
        position: 'center',
        type: 'error',
        title: 'please login',
        showConfirmButton: false,
        timer: 3000
      })
    }
  }
  








  ngOnInit() {
     let a=localStorage.getItem('userId')
     if(a!=undefined){
      this.validate();
this.proser.getprofromcart().subscribe(res=>
  {
    this.resData=res;

         if(this.resData.err==0)
         {
           this.catData=this.resData.cdata;
           this.sum=this.resData.sum
           console.log(this.sum);
          }
})
  }
  else{
    Swal.fire({
      position: 'center',
      type: 'error',
      title: 'please login',
      showConfirmButton: false,
      timer: 3000
    })
  }

}



validate()
  {
    this.myForm=this.fb.group
    (
	    {
          'address'    : ['',Validators.required]
	    	//	'pass'   : ['',[Validators.required,Validators.pattern("^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,30}$")]]
	    }		
    ) 	
  }

}
