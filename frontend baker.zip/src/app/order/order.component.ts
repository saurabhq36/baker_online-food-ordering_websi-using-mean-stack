import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  resData;
  catData;
  constructor(private proser:ProductService) { }

  ngOnInit() {
   this.proser.getorders().subscribe(res=>
    {

      this.resData=res;

         if(this.resData.err==0)
         {
           this.catData=this.resData.cdata;
          }


    }
    )
  }

}
