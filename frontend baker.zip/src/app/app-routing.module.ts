import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ServicesComponent } from './services/services.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { TestimonialComponent } from './testimonial/testimonial.component';
import { BlogComponent } from './blog/blog.component';
import { ContactComponent } from './contact/contact.component';
import { HeaderComponent } from './header/header.component';
import { BodyComponent } from './body/body.component';
import { FooterComponent } from './footer/footer.component';
import { ProfileguardGuard} from './guards/profileguard.guard';
import { MenuComponent } from './menu/menu.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { DefaultproductComponent } from './defaultproduct/defaultproduct.component';
import { CategoryproductComponent } from './categoryproduct/categoryproduct.component';
import { ProductdetailComponent } from './productdetail/productdetail.component';
import { CartComponent } from './cart/cart.component';
import { SearchComponent } from './search/search.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { OrderComponent } from './order/order.component';

const routes: Routes = [
{path:'',component:HomeComponent},
//{path:'header',component:HeaderComponent},
{path:'order',component:OrderComponent},
{path:'about',component:AboutComponent},
{path:'signup',component:SignupComponent},
{path:'login',component:LoginComponent},
{path:'cart',component:CartComponent},
{path:'search',component:SearchComponent},
{path:'services',component:ServicesComponent},
{path:'portfolio',component:PortfolioComponent},
{path:'testimonial',component:TestimonialComponent,canActivate:[ProfileguardGuard]},
{path:'blog',component:BlogComponent},
{path:'contact',component:ContactComponent},
{path:'menu',component:MenuComponent,children:[
{path:'',component:DefaultproductComponent},
{path:'categoryproduct/:category',component:CategoryproductComponent},
{path:'productdetail/:productname',component:ProductdetailComponent}
]}]


// const routes: Routes = [
//   {path:'',component:HomeComponent},
//   {path:'about',component:AboutComponent},
//   {path:'services',component:ServicesComponent},
//   {path:'portfolio',component:PortfolioComponent},
//   {path:'testimonial',component:TestimonialComponent,canActivate:[ProfileguardGuard]},
//   {path:'blog',component:BlogComponent},
//   {path:'contact',component:ContactComponent},
//   {path:'menu',component:MenuComponent,children:[
//   {path:'',component:DefaultproductComponent},
//   {path:'categoryproduct/:category',component:CategoryproductComponent,
//   children:[
//     {path:'productdetail/:productname',component:ProductdetailComponent}
//   ]},
//   {path:'productdetail/:productname',component:ProductdetailComponent}
//   ]}]







@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
