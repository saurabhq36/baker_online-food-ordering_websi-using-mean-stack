import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-defaultproduct',
  templateUrl: './defaultproduct.component.html',
  styleUrls: ['./defaultproduct.component.css']
})
export class DefaultproductComponent implements OnInit {
resData;
catData;
msg;
  constructor(private proser:ProductService) { }


addtocart(pname){
  let a=localStorage.getItem('userId')
  if(a!=undefined){
  this.proser.addprotocart(pname).subscribe(res=>
    {
      Swal.fire({
        position: 'center',
        type: 'success',
        title: 'added to cart',
        showConfirmButton: false,
        timer: 3000
      })
    console.log(res);
})}
else{
  Swal.fire({
    position: 'center',
    type: 'error',
    title: 'please login',
    showConfirmButton: false,
    timer: 3000
  })
}
}


  ngOnInit() {
    this.proser.getpro()
    .subscribe(res=>
      {
         this.resData=res;
         if(this.resData.err==0)
         {
           this.catData=this.resData.cdata;
          // console.log(this.catData);
         }
      })
  }

}
