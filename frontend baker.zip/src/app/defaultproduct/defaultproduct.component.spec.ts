import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultproductComponent } from './defaultproduct.component';

describe('DefaultproductComponent', () => {
  let component: DefaultproductComponent;
  let fixture: ComponentFixture<DefaultproductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefaultproductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultproductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
