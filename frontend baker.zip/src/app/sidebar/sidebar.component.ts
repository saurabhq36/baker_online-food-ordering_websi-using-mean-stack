import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../services/category.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
resData;
catData;
  constructor(private catser:CategoryService) { }

  ngOnInit() {
    this.catser.getCat()
  .subscribe(res=>
    {
       this.resData=res;
       if(this.resData.err==0)
       {
         this.catData=this.resData.cdata;
         console.log(this.catData);
       }
    })
  }

}
