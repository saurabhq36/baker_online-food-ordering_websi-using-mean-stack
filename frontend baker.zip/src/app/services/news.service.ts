import { Injectable } from '@angular/core';
import {HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root' 
})
export class NewsService {

  constructor(private http : HttpClient) { }
  getNews(){
  
  const url ="https://newsapi.org/v2/everything?q=bitcoin&from=2019-05-18&sortBy=publishedAt&apiKey=0d78d451fd1f476c9e531aa37a5cf07b";
  return this.http.get(url);
  }
  
}
