import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  url="http://localhost:7788/api/";
  constructor(private http:HttpClient) { }
  login(data){
    return this.http.post(this.url+"userlogin",data);
  }
  userlogindata(data){
    return this.http.post(this.url+"userlogindata",data);
  }
  getpro()
  {
    return this.http.get(this.url+"getproduct");
  }
  getprofromcart()
  {
    return this.http.get(this.url+"getproductfromcart");
  }
  filterdata(d)
  {
    return this.http.get(this.url+"filterproduct/"+d);
  }
  sendfeedback(data){
   return this.http.post(this.url+"feedback",data)
  }
  fetchProductName(pname){
    return this.http.get(this.url+"productdetail/"+pname)
  }
  addprotocart(pname){
    return this.http.get(this.url+"addtocart/"+pname)
  }
  deleteproductfromcart(pid){
    return this.http.get(this.url+"deletecartproduct/"+pid)
  }
  addquantity(pid){
    return this.http.get(this.url+"addquantity/"+pid)
  }

  minusquantity(pid){
    return this.http.get(this.url+"minusquantity/"+pid)
  }
  orderproduct(addr){
    return this.http.get(this.url+"orderproduct/"+addr)
  }
  getorders(){
    return this.http.get(this.url+"getorder")
  }
}
