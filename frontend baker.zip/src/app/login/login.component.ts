// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import Swal from 'sweetalert2'
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router} from '@angular/router';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  myForm:FormGroup;
  resData;
  errMsg;
  constructor(private fb:FormBuilder,private router:Router,private lser:ProductService) { }
  

  loginSubmit()
  {
     let formData=this.myForm.getRawValue();
     console.log(formData);
     this.lser.userlogindata(formData)
     .subscribe(res=>
      {
        this.resData=res;
        
        if(this.resData.err==0)
        {
          
          
          
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'logged in',
            showConfirmButton: false,
            timer: 1500
          })
          
          
          
          localStorage.setItem('userId',this.resData.user);
          localStorage.setItem('var1',"true");
          localStorage.setItem('var2',"true");
          this.router.navigate(['/'])
          
        }
        if(this.resData.err==1)
        {
           this.errMsg=this.resData.msg;
        
        
        
        // Swal.fire({
        //     position: 'center',
        //     type: 'error',
        //     title: 'logged in',
        //     showConfirmButton: false,
        //     timer: 1500
        //   })
        
        
        
        }
      },err=>
      {
        console.log("api error");
      })
  }



  ngOnInit() {
    this.validate();
  }
  validate()
  {
    this.myForm=this.fb.group(
      {'email':['',Validators.required],
     'password':['',Validators.required]
     }
    )
  }
}
