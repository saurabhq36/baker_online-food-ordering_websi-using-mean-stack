import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Router} from '@angular/router';
import { throwMatDialogContentAlreadyAttachedError } from '@angular/material';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  //eg=true;  error content not displayed
  constructor(private fb:FormBuilder,private router:Router) { }
  //myForm:FormGroup;
userId;
ok;
notok;
  myForm = new FormGroup({
    search: new FormControl()
   });


  search(){
    let formData=this.myForm.getRawValue();
    console.log(formData.search)
    localStorage.setItem('search',formData.search);
          this.router.navigate(['/portfolio']);
  }


  signout(){
    localStorage.removeItem('userId');
    localStorage.setItem('var1',"false")
    this.router.navigate(['/'])
    document.location.reload(true)
  }

  ngOnInit() {
this.userId=localStorage.getItem('userId')
console.log("userid="+this.userId)
if(this.userId==undefined){
  this.ok="abc"}
  else{
  this.notok="abc"
}
}

  }


