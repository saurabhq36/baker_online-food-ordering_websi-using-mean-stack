import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { ProductService } from '../services/product.service';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-categoryproduct',
  templateUrl: './categoryproduct.component.html',
  styleUrls: ['./categoryproduct.component.css']
})
export class CategoryproductComponent implements OnInit {
category;
resdata;
catData;
  constructor(private ar:ActivatedRoute,private catser:ProductService) { }


  addtocart(pname){
    let a=localStorage.getItem('userId')
    if(a!=undefined){
    this.catser.addprotocart(pname).subscribe(res=>
      {
        Swal.fire({
          position: 'center',
          type: 'success',
          title: 'added to cart',
          showConfirmButton: false,
          timer: 3000
        })
      console.log(res);
  })
}
else
{
  Swal.fire({
    position: 'center',
    type: 'error',
    title: 'please login',
    showConfirmButton: false,
    timer: 3000
  })
}
  }




  ngOnInit() {
    this.ar.params.subscribe(par=>
      {
        this.category=par.category;
        console.log(this.category)
        this.catser.filterdata(this.category).subscribe(res=>
          {
            this.resdata=res;
            this.catData=this.resdata.cdata
          }
          )
      })
  }

}






// this.proser.filterdata(d).subscribe(res=>
//   {
//     this.resData=res;
//     if(this.resData.err==0)
//     this.catData=this.resData.cdata;
//     //console.log(res);
//   })